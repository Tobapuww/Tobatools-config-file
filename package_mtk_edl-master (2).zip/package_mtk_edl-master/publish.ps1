param(
    [string]$Publisher,
    [string]$Version,
    [string]$Tip
)

# ������
if ([string]::IsNullOrWhiteSpace($Publisher) -or [string]::IsNullOrWhiteSpace($Version) -or [string]::IsNullOrWhiteSpace($Tip)) {
    Write-Host "����: [string]Publisher [string]Version [string]Tip" -ForegroundColor Red
    exit 1
}

$ConfigPath = "Config.xml"
$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DistDir = Join-Path $CurrentDir "dist"
if (!(Test-Path $DistDir)) {
    New-Item -ItemType Directory -Path $DistDir | Out-Null
}
$PublishDate = [long](([datetime]::UtcNow - [datetime]'1970-01-01').TotalMilliseconds)

# ��ȡ���޸�Config.xml
[xml]$xml = [System.IO.File]::ReadAllText($ConfigPath, [System.Text.Encoding]::UTF8)
$packetInfo = $xml.GeekFlashPacket.PacketInfo
if ($packetInfo -eq $null) {
    Write-Host "Config.xml ��ʽ����δ�ҵ� PacketInfo �ڵ㣡" -ForegroundColor Red
    exit 1
}
$packetInfo.Publisher = $Publisher
$packetInfo.PublishVersion = $Version
$packetInfo.Tip = $Tip
$packetInfo.PublishDate = $PublishDate.ToString()
$xml.Save($ConfigPath)

# ��ȡ������Ҫѹ�����ļ����ų�dist�ļ��У�
$items = Get-ChildItem -Path $CurrentDir -Exclude "dist" | Select-Object -ExpandProperty FullName

# ѹ����dist�ļ���
$ZipName = "GeekFlashPacket_$($Version)_$(Get-Date -Format yyyyMMddHHmmss).zip"
$ZipPath = Join-Path $DistDir $ZipName
Compress-Archive -Path $items -DestinationPath $ZipPath

Write-Host ("������ɣ������ļ���{0}" -f $ZipPath) -ForegroundColor Green