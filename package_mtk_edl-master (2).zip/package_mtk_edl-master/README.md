# 刷机匣联发科资源包

## 发布流程
1. 修改Config.xml
2. 添加文件
3. 通过publish.ps1发布成压缩包

XML格式请看 "Config.xml"

### 发布脚本
```.\publish.ps1 作者 版本号 包说明``` 
```.\publish.ps1 Jackson 1.0.0 测试MTK资源包``` 
